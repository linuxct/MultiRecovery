#!/sbin/sh

if [ ! -f "/system/bin/chargemon.bin" ]; then
	/sbin/busybox mv /system/bin/chargemon /system/bin/chargemon.bin
fi

if [ ! -f "/system/bin/e2fsck.bin" ]; then
	/sbin/busybox mv /system/bin/e2fsck /system/bin/e2fsck.bin
fi

CHARGEMON=`/sbin/busybox sed -n 1p /system/bin/chargemon.bin`
if [ "${CHARGEMON}" = "#!/system/xbin/busybox sh" ]; then

        echo "Creating a backup"
        /sbin/busybox cp /tmp/chargemon /system/bin/chargemon.bin
        /sbin/busybox chown 0.0 /system/bin/chargemon.bin
        /sbin/busybox chmod 0755 /system/bin/chargemon.bin

fi
echo "finished"
exit 0
