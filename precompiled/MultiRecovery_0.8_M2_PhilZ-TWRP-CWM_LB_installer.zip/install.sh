#!/bin/bash

printf "**  MultiRecovery Installer for Xperia M2 LB devices  **\n"
printf "**         By Rachit Rawat, [NUT]                     **\n"
printf "**   Modified by LinuxCT, Andrej732, AleksJ           **\n"

printf "=================================================\n"
printf "Connect Xperia M2 with USB debugging on ...      \n"
printf "=================================================\n"

cd files
adb kill-server
adb start-server
adb wait-for-device
printf "Installing MultiRecovery \n"
printf ".\n"
 
adb shell "mkdir /data/local/tmp/recovery"
adb push recovery.sh /data/local/tmp/recovery
adb push chargemon.sh /data/local/tmp/recovery
adb push e2fsck.sh /data/local/tmp/recovery
adb push twrp/twrp.cpio /data/local/tmp/recovery
adb push philz/philz.cpio /data/local/tmp/recovery
adb push cwm/cwm.cpio /data/local/tmp/recovery
adb push byeselinux/byeselinux.ko /data/local/tmp/recovery
adb push byeselinux/byeselinux.sh /data/local/tmp/recovery
adb push byeselinux/modulecrcpatch /data/local/tmp/recovery
adb push busybox /data/local/tmp/recovery
adb push step3.sh /data/local/tmp/recovery
adb shell "chmod 755 /data/local/tmp/recovery/busybox"
adb shell "chmod 755 /data/local/tmp/recovery/step3.sh"
adb shell "su -c /data/local/tmp/recovery/step3.sh"
adb shell "rm -r /data/local/tmp/recovery"
adb kill-server
 
read -n1 -r -p "Thanks for installing MultiRecovery 0.7. Enjoy...\n"
